from setuptools import setup

setup(
    name="Usuarios",
    version="1.2",
    description="Compra de televisores",
    author="Diego Garcia",
    author_email="diego12_23@yahoo.com.ar",
    packages=["paquete"]
)